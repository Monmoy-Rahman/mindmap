import React from 'react';

function DashboardPage() {
  return (
    <div>
      <h1>Dashboard Page</h1>
      {/* TODO: Display user profile and list mind maps */}
    </div>
  );
}

export default DashboardPage;
