import React from 'react';

function Sidebar() {
  return (
    <div className="w-64 bg-gray-200 p-4">
      <h2 className="text-xl font-bold mb-4">Sidebar</h2>
      {/* TODO: Add sidebar content */}
    </div>
  );
}

export default Sidebar;
